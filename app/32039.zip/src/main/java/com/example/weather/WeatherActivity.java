package com.example.weather;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.Locale;

public class WeatherActivity extends AppCompatActivity {
    private TextView textCity,textCurrentTemp,textTime,textPressure,textHumidity,textMinTemp,textMaxTemp;
    private WeatherData data;
    private ImageView icon;
    private String iconURL;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);
        textCity=findViewById(R.id.textCity);
        textCurrentTemp=findViewById(R.id.textCurrentTemp);
        textTime=findViewById(R.id.textTime);
        textCurrentTemp=findViewById(R.id.textCurrentTemp);
        textPressure=findViewById(R.id.textPressure);
        textHumidity=findViewById(R.id.textHumidity);
        textMinTemp=findViewById(R.id.textMinTemp);
        textMaxTemp=findViewById(R.id.textMaxTemp);
        icon=findViewById(R.id.imageViewIcon);

        Intent intent = getIntent();
        String city_name = intent.getStringExtra("city_name");
        data = (WeatherData) intent.getSerializableExtra("weather_class");
        textCity.setText(data.getName());
        textCurrentTemp.setText(data.getMain().getTemp()+" °C");
        textMinTemp.setText(data.getMain().getTempMin()+" °C");
        textMaxTemp.setText(data.getMain().getTempMax()+" °C");
        textHumidity.setText(data.getMain().getHumidity()+" %");
        textPressure.setText(data.getMain().getPressure()+" hPa");

        iconURL="https://openweathermap.org/img/wn/"+data.getWeather().get(0).getIcon()+"@2x.png";
        Picasso.with(this).load(iconURL).into(icon);

        String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        textTime.setText(currentTime);
    }
}
